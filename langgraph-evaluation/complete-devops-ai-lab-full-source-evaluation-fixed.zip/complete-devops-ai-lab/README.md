# Complete Agentic DevOps Incident Lab — Groq GPT-OSS 120B + Langfuse

A Docker Compose teaching lab with five agents, four read-only synthetic telemetry gateways, LangGraph orchestration, a simulated Flask service, deterministic evaluation, a human-approval-only remediation simulator, and a **self-hosted Langfuse observability stack**.

## Exact model configuration

This lab is configured for **Groq as the inference provider** and **`openai/gpt-oss-120` as the model**.

```env
LLM_PROVIDER=groq
GROQ_API_KEY=your_real_groq_api_key
GROQ_MODEL=openai/gpt-oss-120
```

All five agents use this model initially. Every agent reads `GROQ_MODEL`; the project does not use `MODEL_NAME`.

## Architecture

```text
Browser
  |-- Dashboard :8081
  |-- Langfuse UI :3000
  |
Evaluator :8090 ---- calls ---- LangGraph Orchestrator :8080
                                  |
                                  +-- Monitoring Agent :8201 -- Monitoring gateway :8101
                                  +-- Logs Agent       :8202 -- Logs gateway       :8102
                                  +-- Deployment Agent :8203 -- Deployment gateway :8103
                                  +-- Container Agent  :8204 -- Container gateway  :8104
                                  |
                                  +-- Incident Commander :8205 (Groq GPT-OSS 120B)
                                             |
                                             +-- Evidence-grounded diagnosis
                                             +-- Safe action proposal only
                                                       |
                                                       v
                                          Remediation simulator :8105
                                          Human approval required

Langfuse :3000 <--- traces/generations from all five agents
   |-- PostgreSQL
   |-- ClickHouse
   |-- Redis
   |-- MinIO (object storage)
```

The `*-mcp` services are restricted HTTP tool gateways for synthetic data, not the official MCP Streamable HTTP wire protocol. No host Docker socket, shell, Kubernetes credentials, cloud credentials, or production write access is provided.

## 1. Configure the .env file

```bash
cp .env.example .env
nano .env
```

Put your real Groq API key in `GROQ_API_KEY`. Do not paste the key into chat or commit `.env` to Git.

Langfuse is self-hosted by Compose. Its public/secret project keys are created in the Langfuse UI after first startup; leave them blank for the first startup.

## 2. Start the entire lab

```bash
docker compose up -d --build
docker compose ps
```

First startup can take several minutes because PostgreSQL, ClickHouse, MinIO, Langfuse, and the agent images must initialize.

Open:
- Dashboard: http://localhost:8081
- Langfuse: http://localhost:3000
- Orchestrator API docs: http://localhost:8080/docs
- Evaluator API docs: http://localhost:8090/docs
- Demo app: http://localhost:5000/health

## 3. Enable Langfuse tracing

1. Open http://localhost:3000.
2. Complete the first-user setup.
3. Create a project, for example `DevOps Multi-Agent Lab`.
4. Open the project's settings/API keys and create a public/secret key pair.
5. Copy the keys into `.env`:

```env
LANGFUSE_PUBLIC_KEY=pk-lf-...
LANGFUSE_SECRET_KEY=sk-lf-...
LANGFUSE_HOST=http://langfuse:3000
```

6. Recreate the five agent containers so they receive the keys:

```bash
docker compose up -d --force-recreate monitoring-agent logs-agent deployment-agent container-agent commander-agent
```

7. Run an incident and inspect traces in Langfuse.

The SDK integration is fail-open: if Langfuse is unavailable, incident analysis continues. Langfuse does not decide whether a diagnosis is correct; the evaluator does that separately.

## 4. Run one incident

```bash
curl -sS -X POST http://localhost:8080/investigate \
  -H 'Content-Type: application/json' \
  -d '{"scenario":"cpu_spike"}' | python3 -m json.tool
```

Try:
`healthy`, `stale_alert`, `bad_deployment`, `cpu_spike`, `memory_pressure`, `disk_pressure`, `container_crashloop`, `database_failure`, `network_latency`, `dependency_timeout`, `intermittent_errors`, `config_drift`, `traffic_spike`, `queue_backlog`, `rate_limit`, `auth_failure`, `certificate_expiry`.

## 5. Run the evaluation suite

```bash
curl -sS -X POST http://localhost:8090/run \
  -H 'Content-Type: application/json' \
  -d '{}' | python3 -m json.tool
```

Or select a few cases:

```bash
curl -sS -X POST http://localhost:8090/run \
  -H 'Content-Type: application/json' \
  -d '{"scenarios":["healthy","cpu_spike","bad_deployment"]}' | python3 -m json.tool
```

Evaluation compares the model diagnosis with independent expected ground truth, checks evidence coverage, detects unsafe action language, and verifies that remediation has not been auto-executed. A failed evaluation is useful feedback; do not tune the evaluator merely to make the score green.

## 6. Verify model configuration inside all five agents

```bash
for service in monitoring-agent logs-agent deployment-agent container-agent commander-agent; do
  echo "===== $service ====="
  docker compose exec "$service" sh -c \
    'echo "Provider=$LLM_PROVIDER"; echo "Model=$GROQ_MODEL"; test -n "$GROQ_API_KEY" && echo "Groq key configured" || echo "Groq key MISSING"'
done
```

The Commander calls Groq to produce the root-cause diagnosis. It does not receive the scenario's expected answer. If Groq is unavailable or its response is invalid, the Commander returns `inconclusive` rather than silently substituting a guessed diagnosis.

## 7. Safety model

- All telemetry is synthetic and read-only.
- No Docker socket, host shell, Kubernetes API, cloud credentials, or production write credentials are mounted.
- The remediation service is a local simulator.
- The investigation endpoint never executes remediation.
- Every proposed action requires an explicit approval secret and approval request.
- The Commander is instructed to recommend only `no_action` or a demo rollback proposal.
- Never connect this lab directly to production systems without a separate security review, authorization layer, least-privilege design, and tested rollback plan.

## 8. Troubleshooting

```bash
docker compose ps
docker compose logs -f langfuse
docker compose logs -f commander-agent
docker compose logs -f orchestrator
```

If the Langfuse UI is not ready, wait for ClickHouse and PostgreSQL initialization, then:

```bash
docker compose restart langfuse
```

If Groq returns a model/access error, confirm your Groq account supports the configured model ID and check `docker compose logs commander-agent`.

## 9. Tests

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pytest -q
```

This project has been syntax/configuration checked, but a live Groq request and full multi-container first-boot test require your own API key and Docker runtime. Do not interpret the generated ZIP as proof that external services have started successfully.


## MinIO image registry note

The original MinIO Docker Hub repositories (`minio/minio` and `minio/mc`) were removed, so this Compose file does **not** reference them. It uses the public `chainguard/minio:latest` server image and AWS CLI to create the Langfuse bucket. The MinIO data volume is initialized for the image's non-root UID 65532 before startup.

If you previously created the `langfuse_minio_data` volume with a different MinIO image, back up the volume before changing ownership or replacing images.


## Runtime startup fix (Compose v2)

The orchestrator, evaluator, and dashboard Dockerfiles install dependencies and copy source files; their runtime commands are explicitly set in Compose:
- orchestrator: `uvicorn main:app --host 0.0.0.0 --port 8080`
- evaluator: `uvicorn main:app --host 0.0.0.0 --port 8090`
- dashboard: `python app.py`

The Langfuse bucket initializer uses `amazon/aws-cli:2`; it must not use the MinIO server image because that image does not contain the `mc` client binary.


## Evaluation button behavior

The dashboard's "Run all evaluations" button calls the evaluator API. The evaluator processes scenarios sequentially to avoid sending a burst of concurrent calls to Groq. During evaluation, specialist agents return the raw synthetic evidence without making their own additional LLM calls; the Incident Commander still uses the configured Groq model to produce the diagnosis. The evaluator then compares the diagnosis with the scenario's independent ground truth and reports per-scenario checks.

The bucket bootstrap is built locally from `python:3.12-slim` plus pinned `boto3`; it does not depend on an `amazon/aws-cli` tag.
