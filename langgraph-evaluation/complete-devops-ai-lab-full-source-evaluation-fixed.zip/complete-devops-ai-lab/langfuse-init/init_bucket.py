import os
import time
import boto3
from botocore.config import Config
from botocore.exceptions import ClientError

endpoint = os.getenv("S3_ENDPOINT", "http://langfuse-minio:9000")
access = os.getenv("AWS_ACCESS_KEY_ID", "langfuse")
secret = os.getenv("AWS_SECRET_ACCESS_KEY", "langfuse-minio-password")
bucket = os.getenv("S3_BUCKET", "langfuse")

client = boto3.client(
    "s3",
    endpoint_url=endpoint,
    aws_access_key_id=access,
    aws_secret_access_key=secret,
    region_name="us-east-1",
    config=Config(s3={"addressing_style": "path"}, retries={"max_attempts": 2}),
)

for attempt in range(60):
    try:
        existing = [item["Name"] for item in client.list_buckets().get("Buckets", [])]
        if bucket not in existing:
            client.create_bucket(Bucket=bucket)
        print(f"S3 bucket '{bucket}' is ready at {endpoint}")
        break
    except Exception as exc:
        if attempt == 59:
            raise
        print(f"Waiting for S3 endpoint ({attempt + 1}/60): {exc}", flush=True)
        time.sleep(2)
