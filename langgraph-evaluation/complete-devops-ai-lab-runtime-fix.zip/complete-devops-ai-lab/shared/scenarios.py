import json, os
from pathlib import Path
_DATA = Path(__file__).with_name("scenarios.json")
SCENARIOS = json.loads(_DATA.read_text())
def get_scenario(name):
    if name not in SCENARIOS:
        raise KeyError(f"Unknown scenario: {name}")
    return SCENARIOS[name]
def current_scenario():
    return os.getenv("SCENARIO", "healthy")
