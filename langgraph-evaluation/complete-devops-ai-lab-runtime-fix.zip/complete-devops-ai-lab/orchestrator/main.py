import os, uuid, asyncio, httpx
from typing import TypedDict, Any
from fastapi import FastAPI, HTTPException, Header
from langgraph.graph import StateGraph, START, END
from langgraph.types import Send

URLS={
 "monitoring":os.getenv("MONITORING_AGENT_URL","http://localhost:8201"),
 "logs":os.getenv("LOGS_AGENT_URL","http://localhost:8202"),
 "deployment":os.getenv("DEPLOYMENT_AGENT_URL","http://localhost:8203"),
 "container":os.getenv("CONTAINER_AGENT_URL","http://localhost:8204"),
 "commander":os.getenv("COMMANDER_AGENT_URL","http://localhost:8205")
}
REMEDIATION_URL=os.getenv("REMEDIATION_URL","http://localhost:8105")
APPROVAL_SECRET=os.getenv("APPROVAL_SECRET","local-demo-approval-only")
ALLOWED_SCENARIOS={"healthy","stale_alert","bad_deployment","cpu_spike","memory_pressure","disk_pressure","container_crashloop","database_failure","network_latency","dependency_timeout","intermittent_errors","config_drift","traffic_spike","queue_backlog","rate_limit","auth_failure","certificate_expiry"}
class State(TypedDict, total=False):
    scenario:str
    findings:list
    report:dict
    proposal:dict
    errors:list
    selected_agents:list
async def post_json(url, path, body):
    async with httpx.AsyncClient(timeout=25) as c:
        r=await c.post(url+path,json=body); r.raise_for_status(); return r.json()
async def specialist(name, scenario):
    return await post_json(URLS[name],"/run",{"scenario":scenario})
async def commander(state):
    report=await post_json(URLS["commander"],"/run",{"scenario":state["scenario"],"findings":state.get("findings",[])})
    proposal=await post_json(REMEDIATION_URL,"/proposal",{"scenario":state["scenario"],"action":report.get("recommended_action","no_action")})
    return {"report":report,"proposal":proposal}
def build_graph():
    async def dispatch(state):
        # Dynamic selection based on incident type; selected specialists run concurrently.
        s=state["scenario"]
        if s=="healthy": names=["monitoring","logs"]
        elif s in {"bad_deployment","config_drift"}: names=["monitoring","logs","deployment","container"]
        elif s in {"cpu_spike","memory_pressure","disk_pressure","container_crashloop"}: names=["monitoring","logs","container"]
        elif s in {"database_failure","network_latency","dependency_timeout","intermittent_errors","rate_limit","auth_failure","certificate_expiry","traffic_spike","queue_backlog","stale_alert"}: names=["monitoring","logs","deployment"]
        else: names=["monitoring","logs","deployment","container"]
        return {"selected_agents":names}
    async def run_specialists(state):
        names=state.get("selected_agents",[])
        results=await asyncio.gather(*(specialist(n,state["scenario"]) for n in names),return_exceptions=True)
        findings=[]; errors=[]
        for n,r in zip(names,results):
            if isinstance(r,Exception): errors.append({"agent":n,"error":str(r)})
            else: findings.append(r)
        return {"findings":findings,"errors":errors}
    async def commander_node(state):
        out=await commander(state)
        return out
    g=StateGraph(State)
    g.add_node("route",dispatch)
    g.add_node("specialists",run_specialists)
    g.add_node("commander",commander_node)
    g.add_edge(START,"route")
    g.add_edge("route","specialists")
    g.add_edge("specialists","commander")
    g.add_edge("commander",END)
    return g.compile()
GRAPH=build_graph()
app=FastAPI(title="LangGraph DevOps Orchestrator")
@app.get("/health")
def health(): return {"status":"ok","workflow":"LangGraph","agents":list(URLS)}
@app.post("/investigate")
async def investigate(payload:dict):
    scenario=payload.get("scenario","healthy")
    if scenario not in ALLOWED_SCENARIOS: raise HTTPException(400,"Unknown scenario")
    try: state=await GRAPH.ainvoke({"scenario":scenario,"findings":[],"errors":[]})
    except Exception as e: raise HTTPException(502,f"Investigation failed: {e}")
    report=state.get("report",{})
    return {"incident_id":str(uuid.uuid4()),"scenario":scenario,
            "selected_agents":state.get("selected_agents",[]),
            "findings":state.get("findings",[]),"errors":state.get("errors",[]),
            "report":report,"proposal":state.get("proposal"),
            "model":report.get("model_metadata",{}).get("model","deterministic")}
@app.post("/approve")
async def approve(payload:dict,x_approval_secret:str=Header(default="")):
    if x_approval_secret!=APPROVAL_SECRET: raise HTTPException(403,"Approval secret invalid")
    try:
        async with httpx.AsyncClient(timeout=10) as c:
            r=await c.post(REMEDIATION_URL+"/approve",json=payload,headers={"X-Approval-Secret":x_approval_secret})
            r.raise_for_status(); return r.json()
    except httpx.HTTPStatusError as e: raise HTTPException(e.response.status_code,e.response.text)
    except Exception as e: raise HTTPException(502,str(e))
