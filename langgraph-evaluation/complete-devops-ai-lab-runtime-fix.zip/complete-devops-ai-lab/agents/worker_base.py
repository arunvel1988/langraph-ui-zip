import os, json, httpx
from fastapi import FastAPI, HTTPException
from llm import ask_llm
from observability import trace_agent
def make_worker(agent_name, tool_path, task):
    app=FastAPI(title=f"{agent_name.title()} specialist agent")
    @app.get("/health")
    def health(): return {"status":"ok","agent":agent_name}
    @app.post("/run")
    async def run(payload: dict):
        scenario=payload.get("scenario","healthy")
        base=os.getenv("MCP_URL","http://localhost")
        try:
            async with httpx.AsyncClient(timeout=10) as c:
                r=await c.get(base+tool_path,params={"scenario_name":scenario}); r.raise_for_status(); evidence=r.json()
        except Exception as e:
            raise HTTPException(502,f"Tool gateway failed: {e}")
        # Agent response always preserves raw evidence; LLM text is optional and cannot alter evidence.
        finding={"agent":agent_name,"scenario":scenario,"task":task,
                 "evidence":evidence,"observations":[],"confidence":0.75}
        if agent_name=="monitoring":
            m=evidence.get("metrics",{})
            finding["observations"]=[f"CPU {m.get('cpu')}%",f"Memory {m.get('memory')}%",
              f"Disk {m.get('disk')}%",f"Latency {m.get('latency_ms')} ms",
              f"Error rate {m.get('error_rate')}%"]
        elif agent_name=="logs":
            finding["observations"]=evidence.get("logs",[])
        elif agent_name=="deployment":
            d=evidence.get("deployment",{})
            finding["observations"]=[f"Current version {d.get('current')}",
              f"Previous version {d.get('previous')}",f"Recent change {d.get('recent_change')}"]
        elif agent_name=="container":
            d=evidence.get("container",{})
            finding["observations"]=[f"Container status {d.get('status')}",
              f"Restart count {d.get('restarts')}",f"Container CPU {d.get('cpu')}%"]
        prompt,meta=ask_llm(
          "You are a read-only DevOps evidence analyst. Return JSON with summary and caveats. Do not invent facts or recommend executing commands.",
          finding)
        if prompt:
            try: finding["llm_analysis"]=json.loads(prompt)
            except Exception: finding["llm_analysis"]={"raw":prompt}
        finding["model_metadata"]=meta
        trace_agent(agent_name,scenario,evidence,finding,meta)
        return finding
    return app
