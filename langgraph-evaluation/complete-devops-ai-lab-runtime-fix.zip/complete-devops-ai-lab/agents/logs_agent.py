from worker_base import make_worker
app=make_worker('logs','/tools/logs','Analyze log evidence only; quote exact messages.')
