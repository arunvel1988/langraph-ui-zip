import os, uuid

def trace_agent(agent_name, scenario, inputs, output, metadata=None, trace_id=None):
    public = os.getenv("LANGFUSE_PUBLIC_KEY", "").strip()
    secret = os.getenv("LANGFUSE_SECRET_KEY", "").strip()
    host = os.getenv("LANGFUSE_HOST", "http://langfuse:3000").strip()
    if not (public and secret and host):
        return
    try:
        from langfuse import Langfuse
        client = Langfuse(public_key=public, secret_key=secret, host=host)
        trace = client.trace(
            id=trace_id or str(uuid.uuid4()),
            name=f"devops-{agent_name}",
            input={"scenario": scenario, "payload": inputs},
            output=output,
            metadata={"agent": agent_name, **(metadata or {})},
        )
        if metadata and metadata.get("model"):
            trace.generation(
                name=f"{agent_name}-llm-call",
                model=metadata.get("model"),
                input=inputs,
                output=output,
                usage={
                    "input": metadata.get("prompt_tokens") or 0,
                    "output": metadata.get("completion_tokens") or 0,
                },
                metadata={"provider": metadata.get("provider"), "latency_ms": metadata.get("latency_ms"),
                          "status": metadata.get("status")},
            )
        client.flush()
    except Exception:
        # Tracing must never block the investigation workflow.
        return
