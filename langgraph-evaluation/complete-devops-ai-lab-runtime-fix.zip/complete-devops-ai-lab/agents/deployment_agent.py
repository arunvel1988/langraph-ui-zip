from worker_base import make_worker
app=make_worker('deployment','/tools/deployment','Check release and configuration change correlation.')
