import os, json, time
from openai import OpenAI

def ask_llm(system, user):
    provider = os.getenv("LLM_PROVIDER", "groq").lower()
    key = os.getenv("GROQ_API_KEY", "").strip()
    model = os.getenv("GROQ_MODEL", "openai/gpt-oss-120").strip()

    if provider != "groq" or not key or key == "PASTE_YOUR_GROQ_API_KEY_HERE":
        return None, {"provider": "not_configured", "model": model, "error": "Groq key/provider not configured"}

    start = time.time()
    try:
        client = OpenAI(
            api_key=key,
            base_url="https://api.groq.com/openai/v1",
            timeout=45.0,
            max_retries=1,
        )
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": json.dumps(user, default=str)},
            ],
            temperature=0,
            response_format={"type": "json_object"},
        )
        usage = response.usage
        meta = {
            "provider": "groq",
            "model": response.model or model,
            "latency_ms": round((time.time() - start) * 1000),
            "prompt_tokens": getattr(usage, "prompt_tokens", None),
            "completion_tokens": getattr(usage, "completion_tokens", None),
            "status": "ok",
        }
        return response.choices[0].message.content, meta
    except Exception as exc:
        return None, {
            "provider": "groq", "model": model,
            "latency_ms": round((time.time() - start) * 1000),
            "status": "error", "error": str(exc)[:500],
        }
