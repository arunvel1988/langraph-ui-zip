from worker_base import make_worker
app=make_worker('monitoring','/tools/metrics','Analyze metrics and alert evidence only.')
