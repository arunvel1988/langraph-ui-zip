import json
from fastapi import FastAPI
from llm import ask_llm
from observability import trace_agent

app = FastAPI(title="Incident Commander Agent")

CAUSES = [
    "healthy", "stale_alert", "bad_deployment", "cpu_spike", "memory_pressure",
    "disk_pressure", "container_crashloop", "database_failure", "network_latency",
    "dependency_timeout", "intermittent_errors", "config_drift", "traffic_spike",
    "queue_backlog", "rate_limit", "auth_failure", "certificate_expiry", "inconclusive"
]
SEVERITIES = ["info", "low", "medium", "high", "critical"]

@app.get("/health")
def health():
    return {"status": "ok", "agent": "commander"}

@app.post("/run")
def run(payload: dict):
    findings = payload.get("findings", [])
    # Only evidence is provided to the model. Scenario name and evaluator ground truth
    # are deliberately not included in the diagnosis prompt.
    compact = []
    for f in findings:
        compact.append({
            "agent": f.get("agent"),
            "raw_evidence": f.get("evidence", {}),
            "observations": f.get("observations", []),
            "llm_analysis": f.get("llm_analysis"),
        })

    system = (
        "You are a cautious production DevOps incident commander. Diagnose ONLY from supplied evidence. "
        "Return one JSON object with keys root_cause, severity, confidence (0 to 1), "
        "evidence_used (array of objects with agent and exact observation), "
        "reasoning, uncertainties, recommended_action. "
        "root_cause must be one of: " + ", ".join(CAUSES) + ". "
        "severity must be one of: " + ", ".join(SEVERITIES) + ". "
        "Use inconclusive when evidence is insufficient or conflicting. "
        "Never invent telemetry. Never recommend executing shell commands, killing processes, "
        "restarting containers, deleting resources, changing production, or automatic rollback. "
        "Use recommended_action='no_action' unless a human-reviewed demo proposal is justified. "
        "For bad_deployment only, you may recommend 'propose_demo_rollback'."
    )
    content, meta = ask_llm(system, {"findings": compact})

    if content:
        try:
            candidate = json.loads(content)
            cause = candidate.get("root_cause", "inconclusive")
            severity = candidate.get("severity", "medium")
            action = candidate.get("recommended_action", "no_action")
            if cause not in CAUSES:
                cause = "inconclusive"
            if severity not in SEVERITIES:
                severity = "medium"
            if action not in {"no_action", "propose_demo_rollback"}:
                action = "no_action"
            result = {
                "root_cause": cause,
                "severity": severity,
                "confidence": max(0.0, min(1.0, float(candidate.get("confidence", 0.0)))),
                "evidence_used": candidate.get("evidence_used", []),
                "reasoning": str(candidate.get("reasoning", ""))[:3000],
                "uncertainties": candidate.get("uncertainties", []),
                "recommended_action": action,
                "recommendation": "No action is executed. Any demo remediation requires explicit human approval.",
                "diagnosis_mode": "groq_llm",
            }
        except Exception as exc:
            result = {
                "root_cause": "inconclusive", "severity": "medium", "confidence": 0.0,
                "evidence_used": [], "reasoning": "Model response could not be parsed.",
                "uncertainties": [str(exc)[:300], "Review raw specialist evidence."],
                "recommended_action": "no_action",
                "recommendation": "No action is executed.",
                "diagnosis_mode": "invalid_llm_response",
            }
    else:
        result = {
            "root_cause": "inconclusive", "severity": "medium", "confidence": 0.0,
            "evidence_used": [], "reasoning": "Groq diagnosis unavailable; no rule-based guess was substituted.",
            "uncertainties": [meta.get("error", "Groq is not configured or unavailable.")],
            "recommended_action": "no_action",
            "recommendation": "No action is executed. Configure Groq and rerun.",
            "diagnosis_mode": "llm_unavailable",
        }

    result["model_metadata"] = meta
    trace_agent("commander", payload.get("scenario", "unspecified"), compact, result, meta)
    return result
