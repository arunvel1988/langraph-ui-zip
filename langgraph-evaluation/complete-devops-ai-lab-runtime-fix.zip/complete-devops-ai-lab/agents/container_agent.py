from worker_base import make_worker
app=make_worker('container','/tools/container','Inspect simulated container health evidence only.')
