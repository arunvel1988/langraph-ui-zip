from flask import Flask, jsonify
import os, time
app = Flask(__name__)
SCENARIO = os.getenv("SCENARIO", "healthy")

@app.get("/")
def index():
    return jsonify(service="synthetic-checkout", scenario=SCENARIO, message="DevOps incident simulation")

@app.get("/health")
def health():
    return jsonify(status="ok", service="synthetic-checkout", scenario=SCENARIO)

@app.get("/scenario")
def scenario():
    return jsonify(scenario=SCENARIO, timestamp=int(time.time()))

@app.get("/metrics")
def metrics():
    return jsonify(cpu_percent=12, memory_percent=38, request_latency_ms=45, error_rate=0.1)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
