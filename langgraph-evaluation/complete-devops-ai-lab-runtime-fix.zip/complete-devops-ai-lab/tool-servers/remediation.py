import os, uuid
from fastapi import Header, HTTPException
from common import app_for
app=app_for("remediation")
PROPOSALS={}
@app.post("/proposal")
def create_proposal(payload: dict):
    action=payload.get("action")
    if action not in {"no_action","propose_demo_rollback"}:
        raise HTTPException(400,"Action is not allowlisted")
    pid=str(uuid.uuid4())
    PROPOSALS[pid]={"action":action,"status":"awaiting_human_approval","scenario":payload.get("scenario")}
    return {"proposal_id":pid,**PROPOSALS[pid]}
@app.post("/approve")
def approve(payload: dict, x_approval_secret: str = Header(default="")):
    if x_approval_secret != os.getenv("APPROVAL_SECRET","local-demo-approval-only"):
        raise HTTPException(403,"Approval secret invalid")
    pid=payload.get("proposal_id")
    if pid not in PROPOSALS: raise HTTPException(404,"Proposal not found")
    if PROPOSALS[pid]["status"] != "awaiting_human_approval":
        raise HTTPException(409,"Proposal already decided")
    PROPOSALS[pid]["status"]="approved_simulation_only" if payload.get("approved") else "rejected"
    return {"proposal_id":pid,**PROPOSALS[pid],"executed":False,
            "message":"Simulation state recorded. No infrastructure action was executed."}
