from common import app_for, scenario
from fastapi import Query
app=app_for("container")
@app.get("/tools/container")
def container(scenario_name: str = Query(default="")):
    import json, os
    from pathlib import Path
    all_data=json.loads((Path(__file__).resolve().parent/"shared"/"scenarios.json").read_text())
    name=scenario_name or os.getenv("SCENARIO","healthy")
    data=all_data.get(name,all_data["healthy"])
    return {"scenario":name,"container":data["container"],"source":"synthetic-container-fixture"}
