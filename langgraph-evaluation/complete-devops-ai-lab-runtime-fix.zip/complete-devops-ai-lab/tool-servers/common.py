import os, json
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
DATA = json.loads((Path(__file__).resolve().parent / "shared" / "scenarios.json").read_text())
def app_for(service):
    app=FastAPI(title=f"{service} read-only tool gateway")
    app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
    @app.get("/health")
    def health(): return {"status":"ok","service":service,"mode":"read-only-simulation"}
    @app.post("/scenario")
    def set_scenario(payload: dict):
        name=payload.get("scenario","healthy")
        if name not in DATA: raise HTTPException(404,"Unknown scenario")
        os.environ["SCENARIO"]=name
        return {"scenario":name}
    return app
def scenario():
    name=os.getenv("SCENARIO","healthy")
    return name, DATA.get(name, DATA["healthy"])
