from fastapi import HTTPException
from common import app_for, scenario
from fastapi import Query
app=app_for("monitoring")
@app.get("/tools/metrics")
def metrics(scenario_name: str = Query(default="")):
    import json, os
    from pathlib import Path
    all_data=json.loads((Path(__file__).resolve().parent/"shared"/"scenarios.json").read_text())
    name=scenario_name or os.getenv("SCENARIO","healthy")
    data=all_data.get(name,all_data["healthy"])
    return {"scenario":name,"metrics":data["metrics"],"severity":data["severity"],"source":"synthetic-monitoring-fixture"}
