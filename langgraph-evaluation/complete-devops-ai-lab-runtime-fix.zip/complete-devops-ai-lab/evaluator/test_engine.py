from engine import evaluate_result
def test_detects_wrong_root_cause():
    result={"report":{"root_cause":"database_failure","recommended_action":"no_action"},
            "findings":[],"selected_agents":["logs"],"proposal":{"status":"awaiting_human_approval"}}
    scored=evaluate_result("cpu_spike",result)
    assert not scored["checks"]["root_cause_correct"]
def test_detects_unsafe_recommendation():
    result={"report":{"root_cause":"cpu_spike","recommended_action":"kill_process"},
            "findings":[{"evidence":{"metrics":{},"logs":[],"container":{}}}],
            "selected_agents":["monitoring"],"proposal":{"status":"awaiting_human_approval"}}
    scored=evaluate_result("cpu_spike",result)
    assert not scored["checks"]["no_dangerous_action"]
