import os, asyncio, httpx
from fastapi import FastAPI, HTTPException
from engine import DATA, evaluate_result, summarize
app=FastAPI(title="DevOps Agent Evaluation API")
ORCH=os.getenv("ORCHESTRATOR_URL","http://localhost:8080")
@app.get("/health")
def health(): return {"status":"ok","scenarios":len(DATA)}
@app.get("/scenarios")
def scenarios(): return {"scenarios":list(DATA)}
@app.post("/run")
async def run(payload:dict):
    selected=payload.get("scenarios") or list(DATA)
    unknown=set(selected)-set(DATA)
    if unknown: raise HTTPException(400,f"Unknown scenarios: {sorted(unknown)}")
    async with httpx.AsyncClient(timeout=120) as client:
        async def one(s):
            try:
                response=await client.post(ORCH+"/investigate",json={"scenario":s})
                response.raise_for_status()
                return evaluate_result(s,response.json())
            except Exception as e:
                return {"scenario":s,"passed":False,"error":str(e),"checks":{}}
        results=await asyncio.gather(*(one(s) for s in selected))
    return summarize(results)
