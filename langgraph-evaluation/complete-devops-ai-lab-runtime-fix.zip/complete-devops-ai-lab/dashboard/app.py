import os, requests
from flask import Flask, request, jsonify, render_template_string
app=Flask(__name__)
ORCH=os.getenv("ORCHESTRATOR_URL","http://localhost:8080")
EVAL=os.getenv("EVALUATOR_URL","http://localhost:8090")
PAGE=r"""
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Agentic DevOps Lab</title><style>
body{margin:0;background:#101827;color:#e8eef8;font:15px Arial}header{padding:22px 5%;background:#172338;border-bottom:1px solid #30415d}
main{max-width:1150px;margin:25px auto;padding:0 18px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}
.card{background:#19263a;border:1px solid #30415d;border-radius:12px;padding:20px;margin-bottom:18px}
h1{font-size:22px;margin:0}h2{font-size:18px;margin-top:0}.muted{color:#9eb0c9}
select,button{padding:11px;border-radius:7px;border:1px solid #51627c;background:#243650;color:white}
button{background:#2767b2;cursor:pointer;margin:4px 4px 4px 0}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#0c1421;padding:14px;border-radius:8px;max-height:550px;overflow:auto}
@media(max-width:750px){.grid{grid-template-columns:1fr}}
</style></head><body><header><h1>Agentic DevOps Control Room</h1><div class="muted">Five agents · LangGraph · Evaluation · Human approval</div></header>
<main><div class="grid"><section class="card"><h2>Incident simulation</h2>
<select id="scenario">{% for s in scenarios %}<option value="{{s}}">{{s}}</option>{% endfor %}</select>
<p><button onclick="investigate()">Run investigation</button><button onclick="evaluate()">Run all evaluations</button></p>
<div id="status" class="muted">Ready. Choose a simulated scenario.</div></section>
<section class="card"><h2>Workflow safety</h2><p>Read-only investigation tools only.</p><p>Four specialist agents can be selected dynamically and run concurrently.</p><p>Commander summarizes evidence. Remediation is simulated and requires human approval.</p><p>No production credentials or host Docker socket are mounted.</p></section></div>
<section class="card"><h2>Incident report / agent findings</h2><pre id="report">No investigation run yet.</pre></section>
<section class="card"><h2>Evaluation results</h2><pre id="eval">No evaluation run yet.</pre></section></main>
<script>
async function investigate(){let scenario=document.getElementById('scenario').value;let status=document.getElementById('status');status.textContent='Running agents...';try{let r=await fetch('/api/investigate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({scenario})});let d=await r.json();document.getElementById('report').textContent=JSON.stringify(d,null,2);status.textContent=r.ok?'Investigation complete':'Investigation failed';}catch(e){status.textContent=e.message}}
async function evaluate(){let status=document.getElementById('status');status.textContent='Running evaluation suite...';try{let r=await fetch('/api/evaluate',{method:'POST'});let d=await r.json();document.getElementById('eval').textContent=JSON.stringify(d,null,2);status.textContent='Evaluation complete';}catch(e){status.textContent=e.message}}
</script></body></html>
"""
SCENARIOS=["healthy","stale_alert","bad_deployment","cpu_spike","memory_pressure","disk_pressure","container_crashloop","database_failure","network_latency","dependency_timeout","intermittent_errors","config_drift","traffic_spike","queue_backlog","rate_limit","auth_failure","certificate_expiry"]
@app.get("/")
def index(): return render_template_string(PAGE,scenarios=SCENARIOS)
@app.post("/api/investigate")
def investigate():
    r=requests.post(ORCH+"/investigate",json=request.get_json(force=True),timeout=90)
    return (r.text,r.status_code,{"Content-Type":"application/json"})
@app.post("/api/evaluate")
def evaluate():
    r=requests.post(EVAL+"/run",json={},timeout=300)
    return (r.text,r.status_code,{"Content-Type":"application/json"})
@app.get("/health")
def health(): return jsonify(status="ok")
if __name__=="__main__": app.run(host="0.0.0.0",port=8081)
