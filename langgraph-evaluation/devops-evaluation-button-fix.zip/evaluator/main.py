import os, httpx
from fastapi import FastAPI, HTTPException
from engine import DATA, evaluate_result, summarize

app = FastAPI(title="DevOps Agent Evaluation API")
ORCH = os.getenv("ORCHESTRATOR_URL", "http://localhost:8080")

@app.get("/health")
def health():
    return {"status": "ok", "scenarios": len(DATA)}

@app.get("/scenarios")
def scenarios():
    return {"scenarios": list(DATA)}

@app.post("/run")
async def run(payload: dict):
    selected = payload.get("scenarios") or list(DATA)
    unknown = set(selected) - set(DATA)
    if unknown:
        raise HTTPException(400, f"Unknown scenarios: {sorted(unknown)}")

    results = []
    # One Commander/Groq call at a time. Specialist agents use raw fixture evidence
    # in evaluation mode, preventing 17 x 5 simultaneous model calls and rate bursts.
    timeout = httpx.Timeout(connect=10.0, read=180.0, write=30.0, pool=30.0)
    async with httpx.AsyncClient(timeout=timeout) as client:
        for scenario in selected:
            try:
                response = await client.post(
                    ORCH + "/investigate",
                    json={"scenario": scenario, "evaluation_mode": True},
                )
                response.raise_for_status()
                results.append(evaluate_result(scenario, response.json()))
            except Exception as exc:
                results.append({
                    "scenario": scenario,
                    "passed": False,
                    "error": f"{type(exc).__name__}: {str(exc)}",
                    "checks": {},
                })
    return summarize(results)
