# Complete Agentic DevOps Incident Lab

A self-contained Docker Compose teaching lab containing **five independent agents**, four read-only tool/MCP-style services, a LangGraph orchestrator, a simulated application, a dashboard, a deterministic evaluation service, and optional Langfuse/Jaeger observability.

> Safety boundary: this project is a simulation. No Docker socket, host shell, cloud credentials, Kubernetes credentials, or production write APIs are mounted or passed to agents. Remediation only changes a local in-memory simulation after an explicit approval header.

## Architecture

```text
Browser :8081
    |
    v
Dashboard (Flask)
    |                    Evaluator :8090
    |                         |
    v                         v
LangGraph Orchestrator :8080 <--- POST /run
    |
    +---- parallel ---- Monitoring Agent :8201 ---- Monitoring tool service :8101
    +---- parallel ---- Logs Agent       :8202 ---- Logs tool service       :8102
    +---- parallel ---- Deployment Agent :8203 ---- Deployment tool service:8103
    +---- parallel ---- Container Agent  :8204 ---- Container tool service:8104
    |
    v
Commander Agent :8205
    |
    v
Evidence-based incident report + safe recommendation
    |
    v
Human approval required
    |
    v
Remediation simulator :8105 (allowlisted demo actions only)
```

The `*-mcp` services in this self-contained edition expose narrowly scoped HTTP tool endpoints. They are MCP-style tool gateways rather than the official MCP Streamable HTTP protocol. The separation is intentional: the agents cannot directly inspect Docker or the host. If you need wire-protocol MCP interoperability, these five gateway APIs can be wrapped with the MCP Python SDK without changing the agent/orchestrator contracts.

## Start the project

```bash
cp .env.example .env
docker compose up -d --build
docker compose ps
```

Open:
- Dashboard: http://localhost:8081
- Orchestrator API docs: http://localhost:8080/docs
- Evaluation API docs: http://localhost:8090/docs
- Demo application: http://localhost:5000/health

Default mode is deterministic and works without an LLM API key.

## Run an incident

```bash
curl -X POST http://localhost:8080/investigate \
  -H 'Content-Type: application/json' \
  -d '{"scenario":"cpu_spike"}'
```

Try other scenarios:
`healthy`, `stale_alert`, `bad_deployment`, `cpu_spike`, `memory_pressure`, `disk_pressure`, `container_crashloop`, `database_failure`, `network_latency`, `dependency_timeout`, `intermittent_errors`, `config_drift`, `traffic_spike`, `queue_backlog`, `rate_limit`, `auth_failure`, `certificate_expiry`.

## Run evaluations

```bash
curl -X POST http://localhost:8090/run \
  -H 'Content-Type: application/json' \
  -d '{}'
```

Run selected scenarios:

```bash
curl -X POST http://localhost:8090/run \
  -H 'Content-Type: application/json' \
  -d '{"scenarios":["healthy","cpu_spike","bad_deployment"]}'
```

The evaluation engine compares the final diagnosis with a human-authored ground-truth dataset, checks that evidence is present, and rejects dangerous actions. It is a baseline evaluator, not a proof that a model is correct. Review and improve the expected facts for your own lab.

## Optional Groq LLM

Set in `.env`:

```env
LLM_PROVIDER=groq
GROQ_API_KEY=your_groq_api_key
MODEL_NAME=llama-3.3-70b-versatile
```

Then:

```bash
docker compose up -d --build
```

If no key is supplied, the services use deterministic rule-based outputs. This is useful for repeatable evaluations.

## LLM monitoring with Langfuse

Set these variables in `.env` to your Langfuse Cloud or self-hosted instance:

```env
LANGFUSE_PUBLIC_KEY=...
LANGFUSE_SECRET_KEY=...
LANGFUSE_HOST=https://cloud.langfuse.com
```

Recreate services:

```bash
docker compose up -d --build
```

Each agent creates a Langfuse trace/span when credentials are configured. Avoid sending secrets, customer data, access tokens, or raw production logs to an external observability service. Use redaction and retention controls before using real incident data.

## Optional Jaeger / OpenTelemetry lab

Start Jaeger:

```bash
docker compose --profile observability up -d jaeger
```

Jaeger UI: http://localhost:16686

This stack is included as a local trace-viewing option. Langfuse integration is separately configurable above.

## Human-approved remediation simulation

The report can include a suggested allowlisted action. The orchestrator never executes it during investigation. To approve a proposal, use the API:

```bash
curl -X POST http://localhost:8080/approve \
  -H 'Content-Type: application/json' \
  -H 'X-Approval-Secret: local-demo-approval-only' \
  -d '{"proposal_id":"<proposal_id>","approved":true}'
```

This calls only the remediation simulator. It does not perform a real rollback, restart, process kill, deployment, or infrastructure change.

## Run unit tests locally

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pytest -q
```

## Important interpretation of evaluation scores

- Root-cause accuracy: matches the expected scenario label.
- Evidence coverage: required evidence categories are present.
- Safety: no prohibited actions are recommended.
- Overall pass: all deterministic checks pass.

An LLM-as-judge is deliberately not used as the sole correctness or safety gate. Human-reviewed ground truth and deterministic checks should remain authoritative for high-impact decisions.
