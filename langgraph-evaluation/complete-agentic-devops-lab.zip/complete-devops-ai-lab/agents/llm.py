import os, json, time
from openai import OpenAI
def ask_llm(system, user):
    provider=os.getenv("LLM_PROVIDER","none").lower()
    key=os.getenv("GROQ_API_KEY")
    if provider != "groq" or not key:
        return None, {"provider":"rules","model":"deterministic"}
    client=OpenAI(api_key=key, base_url="https://api.groq.com/openai/v1")
    start=time.time()
    response=client.chat.completions.create(
        model=os.getenv("MODEL_NAME","llama-3.3-70b-versatile"),
        messages=[{"role":"system","content":system},{"role":"user","content":json.dumps(user)}],
        temperature=0.0,
        response_format={"type":"json_object"},
    )
    usage=response.usage
    meta={"provider":"groq","model":response.model,"latency_ms":round((time.time()-start)*1000),
          "prompt_tokens":getattr(usage,"prompt_tokens",None),"completion_tokens":getattr(usage,"completion_tokens",None)}
    return response.choices[0].message.content, meta
