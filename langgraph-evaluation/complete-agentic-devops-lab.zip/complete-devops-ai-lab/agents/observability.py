import os, uuid, json
def trace_agent(agent_name, scenario, inputs, output, metadata=None):
    # Langfuse is optional. Fail-open: tracing must never break incident analysis.
    public=os.getenv("LANGFUSE_PUBLIC_KEY"); secret=os.getenv("LANGFUSE_SECRET_KEY")
    host=os.getenv("LANGFUSE_HOST")
    if not (public and secret and host): return
    try:
        from langfuse import Langfuse
        client=Langfuse(public_key=public, secret_key=secret, host=host)
        trace=client.trace(name=f"devops-agent-{agent_name}", id=str(uuid.uuid4()),
                           input={"scenario":scenario,"input":inputs},
                           metadata=metadata or {})
        trace.generation(name=f"{agent_name}-response", input=inputs, output=output,
                         model=(metadata or {}).get("model","unknown"),
                         usage={"input":(metadata or {}).get("prompt_tokens") or 0,
                                "output":(metadata or {}).get("completion_tokens") or 0})
        client.flush()
    except Exception:
        # Observability outages must not fail the operational workflow.
        pass
