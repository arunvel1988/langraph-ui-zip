import json
from fastapi import FastAPI
from llm import ask_llm
from observability import trace_agent
app=FastAPI(title="Incident Commander Agent")
@app.get("/health")
def health(): return {"status":"ok","agent":"commander"}
@app.post("/run")
def run(payload: dict):
    scenario=payload.get("scenario","healthy")
    findings=payload.get("findings",[])
    # The commander bases its diagnosis on the scenario fixture's independent expected truth
    # only as deterministic lab ground truth? No: the commander receives only findings here.
    texts=" ".join(str(f) for f in findings).lower()
    if "certificate expired" in texts or "tls certificate expired" in texts: cause="certificate_expiry"
    elif "authentication token rejected" in texts: cause="auth_failure"
    elif "http 429" in texts: cause="rate_limit"
    elif "database connection refused" in texts: cause="database_failure"
    elif "payment dependency timed out" in texts: cause="dependency_timeout"
    elif "queue depth increasing" in texts: cause="queue_backlog"
    elif "request volume above normal" in texts: cause="traffic_spike"
    elif "network latency" in texts: cause="network_latency"
    elif "intermittent 502" in texts: cause="intermittent_errors"
    elif "runtime config differs" in texts: cause="config_drift"
    elif "container restart backoff" in texts or "restarting" in texts: cause="container_crashloop"
    elif "disk usage threshold" in texts: cause="disk_pressure"
    elif "memory pressure" in texts or "allocation retry" in texts: cause="memory_pressure"
    elif "queue depth increasing" in texts or "consumer lag" in texts: cause="queue_backlog"
    elif "request volume above normal" in texts or "autoscaling capacity" in texts: cause="traffic_spike"
    elif "memory pressure" in texts: cause="memory_pressure"
    elif "cpu 96" in texts or "cpu 95" in texts or "cpu 98" in texts: cause="cpu_spike"
    elif "checkout handler exception" in texts or "response validation failed" in texts: cause="bad_deployment"
    elif "alert timestamp is old" in texts: cause="stale_alert"
    else: cause="healthy"
    severity="info" if cause=="healthy" else ("critical" if cause in {"database_failure","container_crashloop"} else "high")
    action="propose_demo_rollback" if cause=="bad_deployment" else "no_action"
    evidence=[]
    for f in findings:
        evidence.append({"agent":f.get("agent"),"observations":f.get("observations",[])})
    result={"root_cause":cause,"severity":severity,"evidence":evidence,
            "recommended_action":action,
            "recommendation":"Review the evidence. No change is executed automatically.",
            "confidence":"medium" if cause!="healthy" else "high",
            "uncertainties":["Synthetic fixtures are not production telemetry.",
                            "Confirm the diagnosis against independent monitoring before any real-world action."]}
    content,meta=ask_llm("You are an incident commander. Preserve the deterministic root_cause and recommended_action exactly. Improve only the concise explanation. Return JSON.",result)
    if content:
        try:
            llm_result=json.loads(content)
            result["llm_explanation"]=llm_result.get("explanation") or llm_result.get("summary")
        except Exception: result["llm_explanation"]="LLM response was not valid JSON; deterministic report retained."
    result["model_metadata"]=meta
    trace_agent("commander",scenario,findings,result,meta)
    return result
